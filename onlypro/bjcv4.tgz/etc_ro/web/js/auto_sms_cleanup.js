define(['service'], function(service) {

    var running = false;

    function autoKeepLatest5SimSms() {

        if (running) {
            return;
        }

        running = true;

        service.getSMSMessages({
            page: 0,
            smsCount: 200,
            nMessageStoreType: 0,
            tags: 10,
            orderBy: "order by id desc"
        }, function(data) {

            var messages = data.messages || [];

            if (messages.length <= 5) {
                running = false;
                return;
            }

            var oldIds = [];

            // KEEP newest 5
            // DELETE #6 pataas
            for (var i = 5; i < messages.length; i++) {

                if (messages[i].id != undefined &&
                    messages[i].id != null) {

                    oldIds.push(messages[i].id);
                }
            }

            if (oldIds.length == 0) {
                running = false;
                return;
            }

            service.deleteMessage({
                ids: oldIds
            }, function(data) {

                console.log(
                    "AUTO SIM SMS CLEANUP: deleted " +
                    oldIds.length +
                    " old SMS"
                );

                running = false;

            }, function(error) {

                console.log(
                    "AUTO SIM SMS CLEANUP: delete failed"
                );

                running = false;
            });

        }, function(error) {

            running = false;

            console.log(
                "AUTO SIM SMS CLEANUP: get SMS failed"
            );
        });
    }

    // Run agad pagkabukas ng modem UI
    autoKeepLatest5SimSms();

    // Check every 10 seconds
    setInterval(function() {
        autoKeepLatest5SimSms();
    }, 10000);

});
