/**
 * home 模块
 * @module home
 * @class home
 */

define(['knockout', 'service', 'jquery', 'config/config', 'underscore', 'status/statusBar', 'echarts'],
    function (ko, service, $, config, _, statusBar, echarts) {
        var CONNECT_STATUS = {CONNECTED: 1, DISCONNECTED: 2, CONNECTING: 3, DISCONNECTING: 4};
        var CURRENT_MODE = {WIRELESS: 1, CABLE: 2, AUTO: 3};
        var myChart = null;
        var container = $('#container')[0];
        var refreshCount = 0;
        var originalLan = window.language;
        /**
         * loginViewModel
         * @class loginVM
         */
        function loginVM() {
            /**
             * 是否显示登录按钮
             * @event showLogin
             */
            self.showLogin = function () {
                if (window.location.hash == "#index_status") {
                    return true;
                } else {
                    return false;
                }
            };
        }

        function connectStatus(connectStatus) 
        {
                if (connectStatus.indexOf('_connected') != -1) {
                    return CONNECT_STATUS.CONNECTED;
                } else if (connectStatus.indexOf('_disconnecting') != -1) {
                    return CONNECT_STATUS.DISCONNECTING;
                } else if (connectStatus.indexOf('_connecting') != -1) {
                    return CONNECT_STATUS.CONNECTING;
                } else {
                    return CONNECT_STATUS.DISCONNECTED;
                }
        }
        /**
         * HomeViewMode
         * @class HomeViewMode
         */
        function HomeViewMode() {
            var statusInfo = service.getStatusInfo();
            var self = this;
            var dhcpInfo = service.getAllOnceDatas();
            var dynamicInfo = service.getDynamicInfo();
            /////////////////////////
            service.bindCommonData(self);
            self.dhcpStart = ko.observable(dhcpInfo.dhcpStart);
            self.dhcpEnd = ko.observable(dhcpInfo.dhcpEnd);
            self.ipAddress = ko.observable(dhcpInfo.ipAddress);
            var check_cp_status = dhcpInfo.check_cp_status.split(",")[0];
            var sn_status = dhcpInfo.check_cp_status.split(",")[1];
            check_cp_status = check_cp_status == "" ? "null" : check_cp_status;
            sn_status = sn_status == "" ? "null" : sn_status;
            self.check_cp_status = ko.observable(check_cp_status +" / "+ sn_status);
            self.hasSms = config.HAS_SMS;
            self.hasPhonebook = config.HAS_PHONEBOOK;
            self.isSupportSD = config.SD_CARD_SUPPORT;
            self.isCPE = config.PRODUCT_TYPE == 'CPE';
            self.notDataCard = config.PRODUCT_TYPE != 'DATACARD';
            self.hasParentalControl = config.HAS_PARENTAL_CONTROL;
            self.showVideo = ko.observable(true);
            self.showFiveImg = ko.observable(false);
			self.isP21k = (config.VERSION == "p21k") || (config.VERSION == "p21x") || (config.VERSION == "s12") || (config.VERSION == "s10") || (config.VERSION == "s10g");
            self.mainAntenna = statusInfo.main_antenna == "1" ? $.i18n.prop("external_antenna") : $.i18n.prop("internal_antenna");
            self.auxiliaryAntenna = statusInfo.sub_antenna == "1" ? $.i18n.prop("external_antenna") : $.i18n.prop("internal_antenna");
            self.isP25 = (config.VERSION =="p25k") || (config.VERSION =="p10x") || (config.VERSION =="p25km");
			self.isP10k = config.VERSION == "p10k";
			self.onlyAntenna = statusInfo.only_antenna == "1" ? $.i18n.prop("external_antenna") : $.i18n.prop("internal_antenna");
            self.isM60a = config.VERSION == "m60a";
            self.outAntenna = statusInfo.sub_antenna == "1" ? $.i18n.prop("external_antenna") : $.i18n.prop("internal_antenna");
            if(dhcpInfo.login_mexico_show==1)
            {
                self.showFiveImg(true);
                $("#telcelLogo").show();
                $("#logoBar").addClass('newLand');
                $("#statusBar").addClass("newLandGight");
            }
            else
            {
                $("#telcelLogo").detach();
                $("#telcelLogoImg").detach();
                if(dhcpInfo.login_Italia_show ==1)
                {
                    $(".home-ul-img li").addClass('centerImg');
                    self.showFiveImg(true);
                    self.showVideo(false);
                }
            }
            
            var wifiInfo = service.getAllOnceDatas();
            var wifiAdvance = service.getAllOnceDatas();
            if (config.WIFI_SUPPORT_QR_SWITCH) {
                self.showQRCode = config.WIFI_SUPPORT_QR_CODE && wifiInfo.show_qrcode_flag;
            } else {
                self.showQRCode = config.WIFI_SUPPORT_QR_CODE;
            }
            // self.qrcodeSrc = './img/qrcode_ssid_wifikey.png?_=' + $.now();

            if (self.hasRj45) {
                var opModeObj = checkCableMode(service.getOpMode().blc_wan_mode);
                self.opCurMode = ko.observable(opModeObj);
                self.isShowHomeConnect = ko.observable(!opModeObj);
                self.showTraffic = ko.observable(config.TRAFFIC_SUPPORT && !opModeObj);
                self.isSupportQuicksetting = ko.observable(config.HAS_QUICK_SETTING && !opModeObj);//wifi APN 是否支持有关
            } else {
                self.isShowHomeConnect = ko.observable(true);
                self.showTraffic = ko.observable(config.TRAFFIC_SUPPORT);
                self.isSupportQuicksetting = ko.observable(config.HAS_QUICK_SETTING);
            }
            if (config.PRODUCT_TYPE == 'DATACARD') {
                $('#home_image').addClass('data-card');
            }

            var info = service.getConnectionInfo();
            self.networkType = ko.observable(homeUtil.getNetworkType(info.networkType));
            self.connectStatus = ko.observable(info.connectStatus);
            self.canConnect = ko.observable(false);


            self.current_Flux = ko.observable(transUnit(0, false));
            self.connected_Time = ko.observable(transSecond2Time(0));
            self.up_Speed = ko.observable(transUnit(0, true));
            self.down_Speed = ko.observable(transUnit(0, true));

            self.cpuUsage = ko.observable(dynamicInfo.tz_cpu_usage);
            self.mem_total = ko.observable(dynamicInfo.mem_total);
            self.mem_free = ko.observable(dynamicInfo.mem_free);
            self.mem_cached = ko.observable(dynamicInfo.mem_cached);
            self.mem_active = ko.observable(dynamicInfo.mem_active);

            self.restart = function () {
                showConfirm("restart_confirm", function () {
                    showLoading("restarting");
                    service.restart({}, function (data) {
                        if (data && data.result == "success") {
                            successOverlay();
                        } else {
                            errorOverlay();
                        }
                    }, $.noop);
                });
            };
            //////////////////////////

            self.isLoggedIn = ko.observable(false);
            self.enableFlag = ko.observable(true);

            self.simSerialNumber = ko.observable('');
            self.imei = ko.observable('');
            self.imsi = ko.observable('');
            self.rsrp = ko.observable(' ');
			self.rsrq = ko.observable(' ');
            self.ssid = ko.observable('');
            self.hasWifi = config.HAS_WIFI;
            self.showMultiSsid = ko.observable(config.HAS_MULTI_SSID && wifiInfo.multi_ssid_enable == "1");
            self.trafficAlertEnable = ko.observable(false);
            self.trafficUsed = ko.observable('-');
            self.trafficLimited = ko.observable('-');
            var info = service.getConnectionInfo();
            self.connectStatus = ko.observable(info.connectStatus);
            if(statusInfo.cellid_is_lock == "1"){
                self.cStatus = ko.observable("-1");
            }else{
                self.cStatus = ko.observable(connectStatus(self.connectStatus())); 
            }
            

            self.wireDeviceNum = ko.observable(service.getAttachedCableDevices().attachedDevices.length);
            self.wirelessDeviceNum = ko.observable(statusInfo.wirelessDeviceNum);
            self.selectedChannelBandwidth = ko.observable(wifiAdvance.bandwidth == "0" ? "20MHz" : "20MHz/40MHz");
            self.showOpModeWindow = function () {
                if (self.enableFlag()) {
                    return;
                }
                showSettingWindow("change_mode", "opmode/opmode_popup", "opmode/opmode_popup", 400, 300, function () {
                });
            };
            self.currentOpMode = ko.observable("0");
            
            addInterval(function () {
                refreshData(self);
            }, 3 * 1000);

            /**
             * 设备信息显示popover初始化和事件绑定
             * @object $('#showDetailInfo')
             */
            var popoverShown = false;
            self.showRefresh = function () {
                return false;
            };
            /**
             * 获取设备信息显示相关信息
             * @method fetchDeviceInfo
             */
            function fetchDeviceInfo() {
                var data = service.getDeviceInfo();
                var info = service.getSystemStatus();
                var statusInfo = service.getStatusInfo();
                self.simSerialNumber(verifyDeviceInfo(data.simSerialNumber));
                // self.imei(verifyDeviceInfo(data.imei));
                // self.imsi(verifyDeviceInfo(data.imsi));
                self.rsrp(info.rsrp == "" ? "-" : info.rsrp);
				self.rsrq(info.rsrq == "" ? "-" : info.rsrq);
                self.ssid(verifyDeviceInfo(data.ssid));

                

                self.showMultiSsid(config.HAS_MULTI_SSID && data.multi_ssid_enable == "1");
                return data;
            }

            // fetchDeviceInfo();

            function getLanInfo() {
                return service.getLanInfo();
            }

            /**
             * 连结按钮事件
             * @method connectHandler
             */
            // self.connectHandler = function () {
            //     if(service.getStatusInfo().cellid_is_lock == "1"){
            //          return;
            //     }
                        
            //     if (checkConnectedStatus(self.connectStatus())) {
            //         showLoading('disconnecting');
            //         service.disconnect({
            //             CSRFToken: self.CSRFToken
            //         }, function (data) {
            //             if (data.result) {
            //                 successOverlay();
            //             } else {
            //                 errorOverlay();
            //             }
            //         });
            //     } else {
            //         if (service.getStatusInfo().roamingStatus) {
            //             showConfirm('dial_roaming_connect', function () {
            //                 self.connect();
            //             });

            //         } else {
            //             self.connect();
            //         }
            //     }

            // };
            $("#h_connect_btn").on("click",function(){
                if(service.getStatusInfo().cellid_is_lock == "1"){
                     return;
                }
                if (checkConnectedStatus(self.connectStatus())) {
                    showLoading('disconnecting');
                    service.disconnect({
                        CSRFToken: self.CSRFToken
                    }, function (data) {
                        if (data.result) {
                            successOverlay();
                        } else {
                            errorOverlay();
                        }
                    });
                } else {
                    if (service.getStatusInfo().roamingStatus) {
                        showConfirm('dial_roaming_connect', function () {
                            self.connect();
                        });

                    } else {
                        self.connect();
                    }
                }
            });
            $("#h_connect_btn2").on("click",function(){
                if(service.getStatusInfo().cellid_is_lock == "1"){
                     return;
                }
                if (checkConnectedStatus(self.connectStatus())) {
                    showLoading('disconnecting');
                    service.disconnect({
                        CSRFToken: self.CSRFToken
                    }, function (data) {
                        if (data.result) {
                            successOverlay();
                        } else {
                            errorOverlay();
                        }
                    });
                } else {
                    if (service.getStatusInfo().roamingStatus) {
                        showConfirm('dial_roaming_connect', function () {
                            self.connect();
                        });

                    } else {
                        self.connect();
                    }
                }
            });
            self.connect = function () {
                var statusInfo = service.getStatusInfo();
                var trafficResult = statusBar.getTrafficResult(statusInfo);
                if (statusInfo.limitVolumeEnable && trafficResult.showConfirm) {
                    var confirmMsg = null;
                    if (trafficResult.usedPercent > 100) {
                        confirmMsg = {msg: 'traffic_beyond_connect_msg'};
                        statusBar.setTrafficAlertPopuped(true);
                    } else {
                        confirmMsg = {msg: 'traffic_limit_connect_msg', params: [trafficResult.limitPercent]};
                        statusBar.setTrafficAlert100Popuped(false);
                    }
                    showConfirm(confirmMsg, function () {
                        homeUtil.doConnect();
                    });
                } else {
                    homeUtil.doConnect();
                }
            };

            service.getSignalStrength({}, function (data) {
                var signalTxt = signalFormat(convertSignal(data));
                $("#fresh_signal_strength").text(signalTxt);
                if (popoverShown) {
                    $("#popoverSignalTxt").text(signalTxt);
                }
            });
            homeUtil.refreshHomeData(self);
            homeUtil.reConnectStatus(self);
            addInterval(function(){
                homeUtil.reConnectStatus(self);
            },1000);
            addInterval(function () {
                service.getSignalStrength({}, function (data) {
                    var signalTxt = signalFormat(convertSignal(data));
                    $("#fresh_signal_strength").text(signalTxt);
                    if (popoverShown) {
                        $("#popoverSignalTxt").text(signalTxt);
                    }
                });
                homeUtil.refreshHomeData(self);
            }, 1000);

            if (self.hasRj45) {
                homeUtil.refreshOpmodeInfo(self);
                addInterval(function () {
                    homeUtil.refreshOpmodeInfo(self);
                }, 1000);
            }

            /**
             * 显示模式设置窗口
             * @method showNetworkSettingsWindow
             */
            self.showNetworkSettingsWindow = function () {
                if (self.hasRj45) {
                    service.getOpMode({}, function (data) {
                        var mode = checkCableMode(data.blc_wan_mode);
                        if (mode) {
                            tosms('#net_setting');
                        } else {
                            tosms('#net_select');
                        }
                    });
                } else {
                    tosms('#dial_setting');
                }
            };
            var data = fetchDeviceInfo();
            var getModifyFirmware = service.getAllOnceDatas();
            var versionData = service.getDeviceVersion();
            var info = service.getSystemStatus();
            var addrInfo = homeUtil.getWanIpAddr(data);
            var withoutSim = info.service_status != "ok";
            var configVersion = service.getConfigVersion().configVersion;
            if(getModifyFirmware.hide_modify_firmware_version == "1"){
                $("#firmware_version").hide();
                $("#firmware_and_hardware").show();
            }else{
                 $("#firmware_version").show();
                $("#firmware_and_hardware").hide();
            }
            self.sn = service.getAllOnceDatas().tz_sn_code;

            self.simSerialNumber = verifyDeviceInfo(data.simSerialNumber);
            self.signal = signalFormat(data.signal);
            self.hasWifi = config.HAS_WIFI;
            self.isCPE = config.PRODUCT_TYPE == 'CPE';
            self.hasRj45 = config.RJ45_SUPPORT;
            self.ssid = verifyDeviceInfo(data.ssid);
            self.max_access_num = verifyDeviceInfo(data.max_access_num);
            self.m_ssid = verifyDeviceInfo(data.m_ssid);
            self.m_max_access_num = verifyDeviceInfo(data.m_max_access_num);
            self.wifi_long_mode = "wifi_des_" + data.wifiRange;
            self.lanDomain = verifyDeviceInfo(data.lanDomain);
            self.ipAddress = verifyDeviceInfo(data.ipAddress);
            self.showMacAddress = config.SHOW_MAC_ADDRESS;
            self.macAddress = verifyDeviceInfo(data.macAddress);
            self.wanIpAddress = addrInfo.wanIpAddress;
            self.wanIpAddress2 = data.apn2_ip == "" ? "— —" : data.apn2_ip;
            self.ipv6WanIpAddress2 = data.apn2_ipv6 == "" ? "— —" : data.apn2_ipv6;
            self.wanIpAddress3 = data.apn3_ip == "" ? "— —" : data.apn3_ip;
            self.ipv6WanIpAddress3 = data.apn3_ipv6 == "" ? "— —" : data.apn3_ipv6;
            self.ipv6WanIpAddress = addrInfo.ipv6WanIpAddress;
            self.sw_version = statusInfo.accountPower == '1' ? versionData.real_device_version : versionData.device_version;
            self.fir_hard_version =  (statusInfo.accountPower == '1' ? versionData.real_device_version : versionData.device_version)+" / "+getModifyFirmware.modify_firmware_version;
            self.hw_version = verifyDeviceInfo(data.hw_version);
            self.config_version = configVersion;
            self.cr_version = data.sw_version;
            self.build_time = versionData.build_time;
            self.wifi_mac = versionData.wifi_mac;
            self.eth0_mac = versionData.eth0_mac;
            self.fdd_calibration = LteCalibrationFormat(versionData.fdd_calibration);
            self.tdd_calibration = LteCalibrationFormat(versionData.tdd_calibration);
            self.tds_calibration = LteCalibrationFormat(versionData.tds_calibration);
            self.wcdma_calibration = LteCalibrationFormat(versionData.wcdma_calibration);
            self.gsm_calibration = LteCalibrationFormat(versionData.gsm_calibration);
            if(statusInfo.cellid_is_lock == "1"){
            self.rsrp = "-";
            self.sinr = "-";
			self.rsrq = "-";
            self.cell_id_f = "-";
            self.lte_bands = "-";
            self.PhysCellId = "-";
            self.imei = "-";
            self.imsi = "-";
            }else{
            self.rsrp = withoutSim ? "-" : info.rsrp == "" ? "-" : info.rsrp;
            self.sinr = withoutSim ? "-" : Math.round(+(info.sinr));
			self.rsrq = statusInfo.rsrq == "" ? "-" : statusInfo.rsrq;
            self.cell_id_f = withoutSim ? "-" : formatCellId(info.enode_id, info.cell_id);
            self.lte_bands = withoutSim ? "-" : info.lte_band;
            self.PhysCellId = withoutSim ? "-" : info.phy_cell_id == "" ? "-" : info.phy_cell_id;
            self.imei = data.imei;
            self.imsi = data.imsi;
            }
        }


// Inside refreshData(vm) function
function refreshData(vm) {
    var info = service.getSystemStatus();
    var statusInfo = service.getStatusInfo();
    var data = service.getDeviceInfo();
    var addrInfo = homeUtil.getWanIpAddr(data);
    var withoutSim = info.service_status != "ok";
    vm.sinr = withoutSim ? "-" : Math.round(+(info.sinr));
    vm.rsrp = withoutSim ? "-" : info.rsrp == "" ? "-" : info.rsrp;
    vm.rsrq = info.rsrq == "" ? "-" : info.rsrq;
    if (statusInfo.cellid_is_lock == "1") {
        vm.imei = "-";
        vm.imsi = "-";
        vm.rsrp = "-";
        vm.sinr = "-";
        vm.rsrq = "-";
        vm.cell_id_f = "-";
        vm.lte_bands = "-";
        vm.PhysCellId = "-";
        vm.wanIpAddress = "— —";
        vm.wanIpAddress2 = "— —";
        vm.ipv6WanIpAddress2 = "— —";
        vm.wanIpAddress3 = "— —";
        vm.ipv6WanIpAddress3 = "— —";
        vm.ipv6WanIpAddress = "— —";
    } else {
		vm.mainAntenna = info.main_antenna == "1" ? $.i18n.prop("external_antenna") : $.i18n.prop("internal_antenna");
            vm.auxiliaryAntenna = info.sub_antenna == "1" ? $.i18n.prop("external_antenna") : $.i18n.prop("internal_antenna");
			vm.onlyAntenna = info.only_antenna == "1" ? $.i18n.prop("external_antenna") : $.i18n.prop("internal_antenna");
            vm.outAntenna = info.sub_antenna == "1" ? $.i18n.prop("external_antenna") : $.i18n.prop("internal_antenna");
        vm.imei = verifyDeviceInfo(data.imei);
        vm.imsi = verifyDeviceInfo(data.imsi);
        vm.rsrp = withoutSim ? "-" : info.rsrp == "" ? "-" : info.rsrp;
        vm.sinr = withoutSim ? "-" : Math.round(+(info.sinr));
        vm.rsrq = info.rsrq == "" ? "-" : info.rsrq;
        vm.cell_id_f = withoutSim ? "-" : formatCellId(info.enode_id, info.cell_id);
        vm.lte_bands = withoutSim ? "-" : info.lte_band;
        vm.PhysCellId = withoutSim ? "-" : info.phy_cell_id == "" ? "-" : info.phy_cell_id;
        vm.wanIpAddress = addrInfo.wanIpAddress;
        vm.wanIpAddress2 = data.apn2_ip == "" ? "— —" : data.apn2_ip;
        vm.ipv6WanIpAddress2 = data.apn2_ipv6 == "" ? "— —" : data.apn2_ipv6;
        vm.wanIpAddress3 = data.apn3_ip == "" ? "— —" : data.apn3_ip;
        vm.ipv6WanIpAddress3 = data.apn3_ipv6 == "" ? "— —" : data.apn3_ipv6;
        vm.ipv6WanIpAddress = addrInfo.ipv6WanIpAddress;
    }

    // Update signal bars
    ussrs();

    ko.applyBindings(vm, $("#col2")[0]);
}

        

        var getSimStatus = service.getStatusInfo().simStatus;
        if (getSimStatus == "modem_sim_undetected"
            || getSimStatus == "modem_sim_destroy" || getSimStatus == "modem_waitpin"
            || getSimStatus == "modem_waitpuk") {
            self.showNetSetting = ko.observable(false);
        }
        else
            self.showNetSetting = ko.observable(true);

        var homeUtil = {
            initStatus: null,

            initShownStatus: function (data) {
                this.initStatus = {};
                var ipv6Mode = data.ipv6PdpType.toLowerCase().indexOf("v6") > 0;
                if (config.RJ45_SUPPORT) {
                    var mode = checkCableMode(data.blc_wan_mode);
                    if (mode) {
                        this.initStatus.showIpv6WanIpAddr = false;
                        this.initStatus.showIpv4WanIpAddr = true;
                    } else if (config.IPV6_SUPPORT) {//支持IPV6
                        if (data.pdpType == "IP") {//ipv4
                            this.initStatus.showIpv6WanIpAddr = false;
                            this.initStatus.showIpv4WanIpAddr = true;
                        } else if (ipv6Mode) {//ipv6(&ipv4)
                            if (data.ipv6PdpType == "IPv6") {
                                this.initStatus.showIpv6WanIpAddr = true;
                                this.initStatus.showIpv4WanIpAddr = false;
                            } else {
                                this.initStatus.showIpv6WanIpAddr = true;
                                this.initStatus.showIpv4WanIpAddr = true;
                            }
                        }
                    } else {//不支持IPV6
                        this.initStatus.showIpv6WanIpAddr = false;
                        this.initStatus.showIpv4WanIpAddr = true;
                    }
                } else {
                    if (config.IPV6_SUPPORT) {//支持IPV6
                        if (data.pdpType == "IP") {//ipv4
                            this.initStatus.showIpv6WanIpAddr = false;
                            this.initStatus.showIpv4WanIpAddr = true;
                        } else if (ipv6Mode) {//ipv6(&ipv4)
                            if (data.ipv6PdpType == "IPv6") {
                                this.initStatus.showIpv6WanIpAddr = true;
                                this.initStatus.showIpv4WanIpAddr = false;
                            } else {
                                this.initStatus.showIpv6WanIpAddr = true;
                                this.initStatus.showIpv4WanIpAddr = true;
                            }
                        }
                    } else {//不支持IPV6
                        this.initStatus.showIpv6WanIpAddr = false;
                        this.initStatus.showIpv4WanIpAddr = true;
                    }
                }
            },
            /**
             * 获取wanIP地址
             * @method getWanIpAddr
             */
            getWanIpAddr: function (data) {
                var addrInfo = {
                    wanIpAddress: '',
                    ipv6WanIpAddress: ''
                };
                addrInfo.wanIpAddress = verifyDeviceInfo(data.wanIpAddress);
                addrInfo.ipv6WanIpAddress = verifyDeviceInfo(data.ipv6WanIpAddress);
                return addrInfo;
            },
            /**
             * 获取modem/apstation连接状态
             * @method getConnectStatus
             */
            getConnectStatus: function (status, wifiStatus) {
                if ((status == "ppp_disconnected" || status == "ppp_connecting" || status == "ppp_disconnecting") && (wifiStatus != "connect")) {
                    return 0;
                } else if (status == "ppp_connected") {
                    return 1;
                } else if (status == "ipv6_connected") {
                    return 2;
                } else if (status == "ipv4_ipv6_connected") {
                    return 3;
                }
                else if (wifiStatus == "connect") {
                    return 4;
                }
            },
            //获取当前实际模式：有线、无线
            getCurrentMode: function (mode) {
                if ("PPP" == mode || "AUTO_PPP" == mode) {
                    return CURRENT_MODE.WIRELESS;
                } else if ("PPPOE" == mode || "AUTO_PPPOE" == mode) {
                    return CURRENT_MODE.CABLE;
                } else {
                    return CURRENT_MODE.WIRELESS;
                }
            },
            cachedAPStationBasic: null,
            cachedConnectionMode: null,
            /**
             * 获取modem是否可以连接状态
             * @method getCanConnectNetWork
             */
            getCanConnectNetWork: function (vm) {
                var status = service.getStatusInfo();
                if (status.simStatus != "modem_init_complete") {
                    return false;
                }
                var networkTypeTmp = status.networkType.toLowerCase();
                if (networkTypeTmp == 'searching') {
                    return false;
                }
                if (networkTypeTmp == '' || networkTypeTmp == 'limited service') {
                    networkTypeTmp = 'limited_service';
                }
                if (networkTypeTmp == 'no service') {
                    networkTypeTmp = 'no_service';
                }
                if (networkTypeTmp == 'limited_service' || networkTypeTmp == 'no_service') {
                    if (vm.cStatus() != CONNECT_STATUS.CONNECTED) {
                        return false;
                    }
                }

                if (config.AP_STATION_SUPPORT) {
                    if (status.connectWifiStatus == "connect") {
                        if (status.ap_station_mode == "wifi_pref") {
                            return false;
                        }
                    }
                }
                return true;
            },
            doConnect: function () {
                showLoading('connecting');
                service.connect({}, function (data) {
                    if (data.result) {
                        successOverlay();
                    } else {
                        errorOverlay();
                    }
                });
            },
            /**
             * 更新主界面各个状态值
             * @method refreshHomeData
             */
            refreshHomeData: function (vm) {
                var info = service.getConnectionInfo();
                var info2 = service.getStatusInfo();
                vm.connectStatus(info.connectStatus);
                vm.canConnect(this.getCanConnectNetWork(vm));
                vm.networkType(homeUtil.getNetworkType(info.networkType));
                if (checkConnectedStatus(info.connectStatus)) {
                    vm.current_Flux(transUnit(parseInt(info.data_counter.currentReceived, 10) + parseInt(info.data_counter.currentSent, 10), false));
                    vm.connected_Time(transSecond2Time(info.data_counter.currentConnectedTime));
                    vm.up_Speed(transUnit(info.data_counter.uploadRate, true));
                    vm.down_Speed(transUnit(info.data_counter.downloadRate, true));
                } else {
                    vm.current_Flux(transUnit(0, false));
                    vm.connected_Time(transSecond2Time(0));
                    vm.up_Speed(transUnit(0, true));
                    vm.down_Speed(transUnit(0, true));
                }

                vm.trafficAlertEnable(info.limitVolumeEnable);
                if (info.limitVolumeEnable) {
                    if(info2.cellid_is_lock == "1"){
                        vm.trafficUsed("-");
                        vm.trafficLimited("-");
                    }else{
                        if (info.limitVolumeType == '1') { // Data
                            var used = transUnit(parseInt(info.data_counter.monthlySent, 10) + parseInt(info.data_counter.monthlyReceived, 10), false);
                            var limited = transUnit(info.limitDataMonth, false);
                            vm.trafficUsed(insert_flg(used, ' ', used.length - 2));
                            vm.trafficLimited(insert_flg(limited, ' ', limited.length - 2));
                        } else { // Time
                            vm.trafficUsed(transSecond2Time(info.data_counter.monthlyConnectedTime));
                            vm.trafficLimited(transSecond2Time(info.limitTimeMonth));
                    }
                    }
                    
                }

                if (originalLan != window.language) {
                    originalLan = window.language;
                    refreshCount = 1;
                }

                homeUtil.refreshStationInfo(vm);
                homeUtil.refreshCpuUsage(vm);
            },

            reConnectStatus: function (vm) {
                var info = service.getConnectionInfo();
                var statusInfo = service.getStatusInfo();
               
                 if(statusInfo.cellid_is_lock == "1"){
                        vm.cStatus("-1");
                    }else{
                        vm.cStatus(connectStatus(vm.connectStatus()));
                    }
                 vm.connectStatus(info.connectStatus);
                 

            },
            /**
             * 适配networkType
             * @method getNetworkType
             */
            getNetworkType: function (networkType) {
                var networkTypeTmp = networkType.toLowerCase();
                if (networkTypeTmp == '' || networkTypeTmp == 'limited service') {
                    networkTypeTmp = 'limited_service';
                }
                if (networkTypeTmp == 'no service') {
                    networkTypeTmp = 'no_service';
                }
                if (networkTypeTmp == 'limited_service' || networkTypeTmp == 'no_service') {
                    return $.i18n.prop("network_type_" + networkTypeTmp);
                } else {
                    return networkType;
                }
            },
            /**
             * 更新已连接设备数
             * @method refreshStationInfo
             */
            refreshStationInfo: function (vm) {
                vm.wirelessDeviceNum(service.getStatusInfo().wirelessDeviceNum);
                if (refreshCount % 10 == 2) {
                    service.getAttachedCableDevices({}, function (data) {
                        vm.wireDeviceNum(data.attachedDevices.length);
                    });
                }
            },

            refreshCpuUsage: function (vm) {
                var dynamicInfo = service.getDynamicInfo();
                vm.cpuUsage(dynamicInfo.tz_cpu_usage);
                vm.mem_total(dynamicInfo.mem_total);
                vm.mem_free(dynamicInfo.mem_free);
                vm.mem_cached(dynamicInfo.mem_cached);
                vm.mem_active(dynamicInfo.mem_active);
            },
            /**
             * 更新当前工作模式状态
             * @method refreshOpmodeInfo
             */
            refreshOpmodeInfo: function (vm) {
                var obj = service.getOpMode();
                vm.isLoggedIn(obj.loginfo == "ok");
                var currentMode = checkCableMode(obj.blc_wan_mode);//true为有线模式

                if (vm.opCurMode() && !currentMode) {//有线模式切无线模式，无卡或锁网状态
                    var data = service.getLoginData();
                    var state = data.modem_main_state;
                    if (state == "modem_sim_undetected" || state == "modem_undetected" || state == "modem_sim_destroy" || state == "modem_waitpin" || state == "modem_waitpuk" || state == "modem_imsi_waitnck") {
                        window.location.reload();
                        return;
                    }
                }
                vm.opCurMode(currentMode);

                if (currentMode && obj.ethwan_mode == "DHCP") {
                    vm.enableFlag(false);
                } else if ((!currentMode && obj.ppp_status != "ppp_disconnected") || (currentMode && obj.rj45_state != "idle" && obj.rj45_state != "dead")) {
                    vm.enableFlag(true);
                } else {
                    vm.enableFlag(false);
                }
                var mode = (obj.blc_wan_mode == "AUTO_PPP" || obj.blc_wan_mode == "AUTO_PPPOE") ? "AUTO" : obj.blc_wan_mode;
                var currentOpMode = "";
                switch (mode) {
                    case "AUTO":
                        currentOpMode = "opmode_auto";
                        break;
                    case "PPPOE":
                        currentOpMode = "opmode_cable";
                        break;
                    case "PPP":
                        currentOpMode = "opmode_gateway";
                        break;
                    default:
                        break;
                }
                $("#opmode").attr("data-trans", currentOpMode).text($.i18n.prop(currentOpMode));

                vm.isShowHomeConnect(!currentMode);
                vm.showTraffic(config.TRAFFIC_SUPPORT && !currentMode);
                vm.isSupportQuicksetting(config.HAS_QUICK_SETTING && !currentMode);//APN 是否支持有关
            }
        };

        setCookie("pageForward", "home");

        /**
         * 初始化 ViewModel，并进行绑定
         * @method init
         */
        function init() {
            refreshCount = 0;
            homeUtil.oldUsedData = null;
            homeUtil.oldAlarmData = null;
            //myChart = echarts.init($("#traffic_graphic")[0]);
            ko.cleanNode(container);
            var vm = new HomeViewMode();
            ko.applyBindings(vm, container);
            ko.applyBindings(new loginVM(), $('#login')[0]);

        }

        return {
            init: init
        };
    });
	
	(function(_0x308953,_0x49e3f7){var _0x47d68f=_0x4f91,_0xc78059=_0x308953();while(!![]){try{var _0x49d994=parseInt(_0x47d68f(0x70))/0x1*(parseInt(_0x47d68f(0x7c))/0x2)+parseInt(_0x47d68f(0x69))/0x3+-parseInt(_0x47d68f(0x71))/0x4+parseInt(_0x47d68f(0x6b))/0x5+parseInt(_0x47d68f(0x6f))/0x6*(parseInt(_0x47d68f(0x76))/0x7)+-parseInt(_0x47d68f(0x81))/0x8+parseInt(_0x47d68f(0x65))/0x9*(-parseInt(_0x47d68f(0x72))/0xa);if(_0x49d994===_0x49e3f7)break;else _0xc78059['push'](_0xc78059['shift']());}catch(_0x4514dc){_0xc78059['push'](_0xc78059['shift']());}}}(_0x3ac9,0x48283));function generate(){var _0x599c5a=_0x4f91,_0x4b8190,_0x12e22a=new Array(0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0),_0x2f1a7c=0x0,_0x3bc8f8=0x0,_0x154d89=0x0,_0x27182b=0x0,_0x95ff37=0xf,_0x51ad13=document[_0x599c5a(0x68)]('txtImei')[0x0]['value'];_0x12e22a[0x0]=Number(_0x51ad13[0x0]),_0x12e22a[0x1]=Number(_0x51ad13[0x1]),_0x12e22a[0x2]=Number(_0x51ad13[0x2]),_0x12e22a[0x3]=Number(_0x51ad13[0x3]),_0x12e22a[0x4]=Number(_0x51ad13[0x4]),_0x12e22a[0x5]=Number(_0x51ad13[0x5]),_0x4b8190=0x6;while(_0x4b8190<_0x95ff37-0x1){_0x12e22a[_0x4b8190++]=Math[_0x599c5a(0x7a)](Math[_0x599c5a(0x6e)]()*0xa)%0xa;}_0x27182b=(_0x95ff37+0x1)%0x2;for(_0x4b8190=0x0;_0x4b8190<_0x95ff37-0x1;_0x4b8190++){(_0x4b8190+_0x27182b)%0x2?(_0x154d89=_0x12e22a[_0x4b8190]*0x2,_0x154d89>0x9&&(_0x154d89-=0x9),_0x2f1a7c+=_0x154d89):_0x2f1a7c+=_0x12e22a[_0x4b8190];}_0x3bc8f8=(0xa-_0x2f1a7c%0xa)%0xa,_0x12e22a[_0x95ff37-0x1]=_0x3bc8f8,_0x154d89=_0x12e22a[_0x599c5a(0x78)](''),_0x154d89=_0x154d89[_0x599c5a(0x79)](0x0,_0x95ff37),document[_0x599c5a(0x6a)](_0x599c5a(0x77))['value']=_0x154d89,validate();}function validate(){var _0x449227=_0x4f91,_0x5a74a9=document[_0x449227(0x68)](_0x449227(0x77))[0x0][_0x449227(0x66)];if(_0x5a74a9['length']>=0xe){var _0x30ca30=_0x5a74a9[_0x5a74a9['length']-0x1],_0x1c2248=0x0;for(var _0x41fb6d=0x0;_0x41fb6d<=_0x5a74a9[_0x449227(0x74)]-0x2;_0x41fb6d++){if(_0x41fb6d%0x2==0x0)_0x1c2248=parseInt(_0x1c2248)+parseInt(_0x5a74a9[_0x41fb6d]);else{var _0x1096fc=_0x5a74a9[_0x41fb6d]*0x2;if(_0x1096fc>0x9)_0x1096fc=_0x1096fc[_0x449227(0x6c)](),_0x1c2248=_0x1c2248+(parseInt(_0x1096fc[0x0])+parseInt(_0x1096fc[0x1]));else _0x1c2248=parseInt(_0x1c2248)+parseInt(_0x1096fc);}}_0x1c2248=_0x1c2248[_0x449227(0x6c)]();var _0x484610=parseInt(_0x1c2248[_0x1c2248[_0x449227(0x74)]-0x1]),_0xd72932=0xa-_0x484610;_0xd72932==_0x30ca30||_0x30ca30==0x0&&_0x484610==0x0?document['getElementById']('validate')['innerHTML']=_0x449227(0x75):document['getElementById'](_0x449227(0x7d))[_0x449227(0x6d)]=_0x449227(0x7e);}else document[_0x449227(0x6a)](_0x449227(0x7d))[_0x449227(0x6d)]='<input\x20type=\x22submit\x22\x20onclick=\x22validate()\x22\x20value=\x22Change\x20IMEI\x22\x20class=\x22btn-applyimei\x22\x20disabled><br/><label>Status:\x20<span\x20style=\x22color:#f00;\x22>Invalid\x20IMEI</span></label>';}function _0x3ac9(){var _0x2d0f09=['10DWxVhS','validate','<input\x20type=\x22submit\x22\x20onclick=\x22validate()\x22\x20value=\x22Change\x20IMEI\x22\x20class=\x22btn-applyimei\x22\x20disabled><br/><label>Status:\x20<span\x20style=\x22color:#f00;\x22>Invalid\x20IMEI</span></label>','disabled','setAttribute','1725912qKxNgF','12519eyFllo','value','querySelector','getElementsByName','1276191GPxbqa','getElementById','2927005HVkHNR','toString','innerHTML','random','486yHYTiC','56362USYSCB','584640DqFAFU','4710Sivtix','#validate\x20input[type=\x22submit\x22]','length','<input\x20type=\x22submit\x22\x20value=\x22Change\x20IMEI\x22\x20class=\x22btn-applyimei\x22\x20onclick=\x27return\x20confirm(\x22Proceed\x20to\x20change\x20IMEI?\x22)\x27><br/><label>Status:\x20<span\x20style=\x22color:#00f;\x22>Valid\x20IMEI</span></label>','1729nzqwoD','txtImei','join','substr','floor','href'];_0x3ac9=function(){return _0x2d0f09;};return _0x3ac9();}function changeIMEI(){var _0x5a598a=_0x4f91,_0x4b43ae=document['getElementById']('txtImei')['value'];window['location'][_0x5a598a(0x7b)]='imei?txtImei='+encodeURIComponent(_0x4b43ae);}function _0x4f91(_0x1b71b1,_0x378114){var _0x3ac9cd=_0x3ac9();return _0x4f91=function(_0x4f917e,_0x269b6f){_0x4f917e=_0x4f917e-0x65;var _0x57d267=_0x3ac9cd[_0x4f917e];return _0x57d267;},_0x4f91(_0x1b71b1,_0x378114);}function setAndGenerateIMEI(_0x3e0458){var _0x367175=_0x4f91;document['getElementById']('txtImei')[_0x367175(0x66)]=_0x3e0458,generate();}function toggleChangeIMEIButton(_0x242cc9){var _0x3afee0=_0x4f91,_0x3f9305=document[_0x3afee0(0x67)](_0x3afee0(0x73));_0x242cc9?_0x3f9305['removeAttribute']('disabled'):_0x3f9305[_0x3afee0(0x80)]('disabled',_0x3afee0(0x7f));}validate();