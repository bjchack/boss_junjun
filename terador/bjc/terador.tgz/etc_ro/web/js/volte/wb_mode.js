define([ 'jquery', 'knockout', 'config/config', 'service', 'underscore' ],
function($, ko, config, service, _) {
    var arrForm = ["frmStaticIpSwitch","frmStaticIpSwitchDiv","frmStaticIpSwitchClass"];
    function DdnsViewModel(){
        var self = this;
        var info = service.getAllOnceDatas();
        self.port_settings = ko.observable(info.wb_mode = "" ? "0" : info.wb_mode);
        creatForm(arrForm);
         self.save = function() {;
            showLoading('waiting');
            service.wbMode({
                digitmap_switch:self.port_settings()
            }, function(result) {
                if (result.result == "success") {
                      successOverlay();
                           
                } else {
                    errorOverlay();
                }
            });
        }
        self.submitApply = function(){

             self.save();
        }
        service.bindCommonData(self);
        
}
    function init() {
        if(this.init){
            getRightNav(VOLTE_SETTINGS_URL);
            getInnerHeader(INNER_HEADER_COMMON_URL);
        }
        var container = $('#container');
        ko.cleanNode(container[0]);
        var vm = new DdnsViewModel();
        ko.applyBindings(vm, container[0]);
    }
    
    return {
        init: init
    };
});